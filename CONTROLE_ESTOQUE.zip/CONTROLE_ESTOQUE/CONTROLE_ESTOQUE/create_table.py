import sqlite3

conn = sqlite3.connect('database.db')
print("Conectado ao banco de dados com sucesso")

conn.execute('CREATE TABLE products (name TEXT, description TEXT, quantity INTEGER, low_stock_limit INTEGER)')
print("Tabela criada com sucesso!")

conn.close()
