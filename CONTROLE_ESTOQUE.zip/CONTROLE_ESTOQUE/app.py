from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

# Home Page route
@app.route("/")
def home():
    return render_template("home.html")

# Route to form used to add a new product to the database
@app.route("/enternew")
def enternew():
    return render_template("product.html")

# Route to add a new record (INSERT) product data to the database
@app.route("/addrec", methods=['POST'])
def addrec():
    if request.method == 'POST':
        try:
            name = request.form['name']
            description = request.form['description']
            quantity = request.form['quantity']
            low_stock_limit = request.form['low_stock_limit']

            with sqlite3.connect('database.db') as con:
                cur = con.cursor()
                cur.execute("INSERT INTO products (name, description, quantity, low_stock_limit) VALUES (?,?,?,?)", 
                            (name, description, quantity, low_stock_limit))

                con.commit()
                msg = "Produto adicionado com sucesso!"
        except:
            con.rollback()
            msg = "Erro ao adicionar o produto."

        finally:
            con.close()
            return render_template('result.html', msg=msg)

# Route to SELECT all data from the database and display in a table      
@app.route('/list')
def list():
    con = sqlite3.connect("database.db")
    con.row_factory = sqlite3.Row

    cur = con.cursor()
    cur.execute("SELECT rowid, * FROM products")

    rows = cur.fetchall()
    con.close()
    return render_template("list.html", rows=rows)

# Route that will SELECT a specific row in the database then load an Edit form 
@app.route("/edit", methods=['POST', 'GET'])
def edit():
    if request.method == 'POST':
        try:
            id = request.form['id']
            con = sqlite3.connect("database.db")
            con.row_factory = sqlite3.Row

            cur = con.cursor()
            cur.execute("SELECT rowid, * FROM products WHERE rowid = " + id)

            rows = cur.fetchall()
        except:
            id = None
        finally:
            con.close()
            return render_template("edit.html", rows=rows)

# Route used to execute the UPDATE statement on a specific record in the database
@app.route("/editrec", methods=['POST'])
def editrec():
    if request.method == 'POST':
        try:
            rowid = request.form['rowid']
            name = request.form['name']
            description = request.form['description']
            quantity = request.form['quantity']
            low_stock_limit = request.form['low_stock_limit']

            with sqlite3.connect('database.db') as con:
                cur = con.cursor()
                cur.execute("UPDATE products SET name=?, description=?, quantity=?, low_stock_limit=? WHERE rowid=?", 
                            (name, description, quantity, low_stock_limit, rowid))

                con.commit()
                msg = "Produto editado com sucesso!"
        except:
            con.rollback()
            msg = "Erro ao editar o produto."

        finally:
            con.close()
            return render_template('result.html', msg=msg)

# Route used to DELETE a specific record in the database    
@app.route("/delete", methods=['POST'])
def delete():
    if request.method == 'POST':
        try:
            rowid = request.form['id']
            with sqlite3.connect('database.db') as con:
                cur = con.cursor()
                cur.execute("DELETE FROM products WHERE rowid=?", (rowid,))

                con.commit()
                msg = "Produto excluído com sucesso!"
        except:
            con.rollback()
            msg = "Erro ao excluir o produto."

        finally:
            con.close()
            return render_template('result.html', msg=msg)

if __name__ == "__main__":
    app.run(debug=True)
